package com.bthid.controller.input

/**
 * HID Key codes for special/function keys.
 * Used to send non-printable key events.
 */
object KeyCodes {
    // Modifiers
    const val MOD_NONE = 0x00
    const val MOD_LCTRL = 0x01
    const val MOD_LSHIFT = 0x02
    const val MOD_LALT = 0x04
    const val MOD_LGUI = 0x08   // Windows/Command key
    const val MOD_RCTRL = 0x10
    const val MOD_RSHIFT = 0x20
    const val MOD_RALT = 0x40
    const val MOD_RGUI = 0x80

    // Special keys
    const val KEY_NONE = 0x00.toByte()
    const val KEY_BACKSPACE = 0x2A.toByte()
    const val KEY_TAB = 0x2B.toByte()
    const val KEY_ENTER = 0x28.toByte()
    const val KEY_ESCAPE = 0x29.toByte()
    const val KEY_DELETE = 0x4C.toByte()
    const val KEY_HOME = 0x4A.toByte()
    const val KEY_END = 0x4D.toByte()
    const val KEY_PAGE_UP = 0x4B.toByte()
    const val KEY_PAGE_DOWN = 0x4E.toByte()
    const val KEY_CAPS_LOCK = 0x39.toByte()

    // Arrow keys
    const val KEY_UP = 0x52.toByte()
    const val KEY_DOWN = 0x51.toByte()
    const val KEY_LEFT = 0x50.toByte()
    const val KEY_RIGHT = 0x4F.toByte()

    // Function keys
    const val KEY_F1 = 0x3A.toByte()
    const val KEY_F2 = 0x3B.toByte()
    const val KEY_F3 = 0x3C.toByte()
    const val KEY_F4 = 0x3D.toByte()
    const val KEY_F5 = 0x3E.toByte()
    const val KEY_F6 = 0x3F.toByte()
    const val KEY_F7 = 0x40.toByte()
    const val KEY_F8 = 0x41.toByte()
    const val KEY_F9 = 0x42.toByte()
    const val KEY_F10 = 0x43.toByte()
    const val KEY_F11 = 0x44.toByte()
    const val KEY_F12 = 0x45.toByte()

    // Mouse button constants
    const val MOUSE_BTN_LEFT = 0x01
    const val MOUSE_BTN_RIGHT = 0x02
    const val MOUSE_BTN_MIDDLE = 0x04
}
