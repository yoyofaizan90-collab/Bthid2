package com.bthid.controller.ui

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.bthid.controller.R
import com.bthid.controller.bluetooth.HidDeviceManager
import com.bthid.controller.input.KeyCodes
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private lateinit var hidManager: HidDeviceManager

    // UI elements
    private lateinit var statusText: TextView
    private lateinit var statusDot: View
    private lateinit var trackpad: View
    private lateinit var btnLeftClick: Button
    private lateinit var btnRightClick: Button
    private lateinit var btnMiddleClick: Button
    private lateinit var btnScrollUp: Button
    private lateinit var btnScrollDown: Button
    private lateinit var keyboardPanel: LinearLayout
    private lateinit var textInput: EditText
    private lateinit var btnSendText: Button
    private lateinit var btnBackspace: Button
    private lateinit var btnEnter: Button
    private lateinit var btnEscape: Button
    private lateinit var btnTab: Button
    private lateinit var btnCtrl: ToggleButton
    private lateinit var btnShift: ToggleButton
    private lateinit var btnAlt: ToggleButton
    private lateinit var btnShowKeyboard: Button
    private lateinit var btnArrowUp: Button
    private lateinit var btnArrowDown: Button
    private lateinit var btnArrowLeft: Button
    private lateinit var btnArrowRight: Button
    private lateinit var sensitivitySeekBar: SeekBar
    private lateinit var btnMakeDiscoverable: Button

    // Trackpad state
    private var lastX = 0f
    private var lastY = 0f
    private var isDragging = false
    private var trackpadSensitivity = 2.0f

    // Modifier state
    private var modifiers = 0

    companion object {
        private const val REQUEST_BLUETOOTH_PERMISSIONS = 1001
        private const val REQUEST_ENABLE_BT = 1002
        private const val REQUEST_DISCOVERABLE = 1003
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Keep screen on while controlling
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        bindViews()
        setupHidManager()
        setupTrackpad()
        setupButtons()
        setupKeyboard()
        setupSensitivity()

        requestPermissions()
    }

    private fun bindViews() {
        statusText = findViewById(R.id.statusText)
        statusDot = findViewById(R.id.statusDot)
        trackpad = findViewById(R.id.trackpad)
        btnLeftClick = findViewById(R.id.btnLeftClick)
        btnRightClick = findViewById(R.id.btnRightClick)
        btnMiddleClick = findViewById(R.id.btnMiddleClick)
        btnScrollUp = findViewById(R.id.btnScrollUp)
        btnScrollDown = findViewById(R.id.btnScrollDown)
        keyboardPanel = findViewById(R.id.keyboardPanel)
        textInput = findViewById(R.id.textInput)
        btnSendText = findViewById(R.id.btnSendText)
        btnBackspace = findViewById(R.id.btnBackspace)
        btnEnter = findViewById(R.id.btnEnter)
        btnEscape = findViewById(R.id.btnEscape)
        btnTab = findViewById(R.id.btnTab)
        btnCtrl = findViewById(R.id.btnCtrl)
        btnShift = findViewById(R.id.btnShift)
        btnAlt = findViewById(R.id.btnAlt)
        btnShowKeyboard = findViewById(R.id.btnShowKeyboard)
        btnArrowUp = findViewById(R.id.btnArrowUp)
        btnArrowDown = findViewById(R.id.btnArrowDown)
        btnArrowLeft = findViewById(R.id.btnArrowLeft)
        btnArrowRight = findViewById(R.id.btnArrowRight)
        sensitivitySeekBar = findViewById(R.id.sensitivitySeekBar)
        btnMakeDiscoverable = findViewById(R.id.btnMakeDiscoverable)
    }

    private fun setupHidManager() {
        hidManager = HidDeviceManager(this)

        hidManager.onStateChanged = { status ->
            runOnUiThread {
                statusText.text = status
                val connected = hidManager.isConnected
                statusDot.setBackgroundResource(
                    if (connected) R.drawable.dot_connected else R.drawable.dot_disconnected
                )
            }
        }

        hidManager.onDeviceConnected = { device ->
            runOnUiThread {
                Toast.makeText(this, "Connected to ${device.name ?: device.address}", Toast.LENGTH_SHORT).show()
            }
        }

        hidManager.onDeviceDisconnected = {
            runOnUiThread {
                Toast.makeText(this, "Device disconnected", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @android.annotation.SuppressLint("ClickableViewAccessibility")
    private fun setupTrackpad() {
        trackpad.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = event.x
                    lastY = event.y
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.x - lastX
                    val dy = event.y - lastY

                    if (abs(dx) > 1 || abs(dy) > 1) {
                        isDragging = true
                        // Scale and clamp movement
                        val scaledDx = (dx * trackpadSensitivity).toInt().coerceIn(-127, 127)
                        val scaledDy = (dy * trackpadSensitivity).toInt().coerceIn(-127, 127)
                        hidManager.sendMouseMove(scaledDx, scaledDy)
                        lastX = event.x
                        lastY = event.y
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        // Tap = left click
                        hidManager.sendMouseClick(KeyCodes.MOUSE_BTN_LEFT)
                    }
                    true
                }
                else -> false
            }
        }

        // Two-finger tap for right click (detect via pointer count)
        // Handled in dispatchTouchEvent override below
    }

    private fun setupButtons() {
        btnLeftClick.setOnClickListener { hidManager.sendMouseClick(KeyCodes.MOUSE_BTN_LEFT) }
        btnRightClick.setOnClickListener { hidManager.sendMouseClick(KeyCodes.MOUSE_BTN_RIGHT) }
        btnMiddleClick.setOnClickListener { hidManager.sendMouseClick(KeyCodes.MOUSE_BTN_MIDDLE) }

        btnScrollUp.setOnClickListener { hidManager.sendScroll(-3) }
        btnScrollDown.setOnClickListener { hidManager.sendScroll(3) }

        // Hold for continuous scroll
        btnScrollUp.setOnLongClickListener {
            repeat(5) { hidManager.sendScroll(-3) }
            true
        }
        btnScrollDown.setOnLongClickListener {
            repeat(5) { hidManager.sendScroll(3) }
            true
        }

        btnMakeDiscoverable.setOnClickListener {
            val discoverableIntent = Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE).apply {
                putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120)
            }
            startActivityForResult(discoverableIntent, REQUEST_DISCOVERABLE)
        }
    }

    private fun setupKeyboard() {
        btnShowKeyboard.setOnClickListener {
            keyboardPanel.visibility = if (keyboardPanel.visibility == View.VISIBLE)
                View.GONE else View.VISIBLE
        }

        btnSendText.setOnClickListener {
            val text = textInput.text.toString()
            if (text.isNotEmpty()) {
                Thread { hidManager.sendText(text) }.start()
                textInput.text.clear()
            }
        }

        btnBackspace.setOnClickListener {
            hidManager.sendKeyPress(modifiers, KeyCodes.KEY_BACKSPACE)
        }
        btnEnter.setOnClickListener {
            hidManager.sendKeyPress(modifiers, KeyCodes.KEY_ENTER)
        }
        btnEscape.setOnClickListener {
            hidManager.sendKeyPress(modifiers, KeyCodes.KEY_ESCAPE)
        }
        btnTab.setOnClickListener {
            hidManager.sendKeyPress(modifiers, KeyCodes.KEY_TAB)
        }

        btnArrowUp.setOnClickListener { hidManager.sendKeyPress(modifiers, KeyCodes.KEY_UP) }
        btnArrowDown.setOnClickListener { hidManager.sendKeyPress(modifiers, KeyCodes.KEY_DOWN) }
        btnArrowLeft.setOnClickListener { hidManager.sendKeyPress(modifiers, KeyCodes.KEY_LEFT) }
        btnArrowRight.setOnClickListener { hidManager.sendKeyPress(modifiers, KeyCodes.KEY_RIGHT) }

        // Modifier toggles — they stay active until toggled off
        btnCtrl.setOnCheckedChangeListener { _, checked ->
            modifiers = if (checked) modifiers or KeyCodes.MOD_LCTRL
            else modifiers and KeyCodes.MOD_LCTRL.inv()
        }
        btnShift.setOnCheckedChangeListener { _, checked ->
            modifiers = if (checked) modifiers or KeyCodes.MOD_LSHIFT
            else modifiers and KeyCodes.MOD_LSHIFT.inv()
        }
        btnAlt.setOnCheckedChangeListener { _, checked ->
            modifiers = if (checked) modifiers or KeyCodes.MOD_LALT
            else modifiers and KeyCodes.MOD_LALT.inv()
        }

        // Intercept physical keyboard if attached to primary phone
        textInput.setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_DOWN) {
                // Pass through to HID
                val hidMod = androidModToHid(event.metaState)
                val hidKey = androidKeyToHid(keyCode)
                if (hidKey != KeyCodes.KEY_NONE) {
                    hidManager.sendKeyPress(hidMod, hidKey)
                    return@setOnKeyListener true
                }
            }
            false
        }
    }

    private fun setupSensitivity() {
        sensitivitySeekBar.max = 40 // 0.5x to 4.5x (step 0.1)
        sensitivitySeekBar.progress = 15 // default ~2x
        sensitivitySeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                trackpadSensitivity = 0.5f + (progress * 0.1f)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
    }

    private fun androidModToHid(metaState: Int): Int {
        var mod = 0
        if (metaState and KeyEvent.META_CTRL_ON != 0) mod = mod or KeyCodes.MOD_LCTRL
        if (metaState and KeyEvent.META_SHIFT_ON != 0) mod = mod or KeyCodes.MOD_LSHIFT
        if (metaState and KeyEvent.META_ALT_ON != 0) mod = mod or KeyCodes.MOD_LALT
        if (metaState and KeyEvent.META_META_ON != 0) mod = mod or KeyCodes.MOD_LGUI
        return mod
    }

    private fun androidKeyToHid(keyCode: Int): Byte {
        return when (keyCode) {
            KeyEvent.KEYCODE_A -> 0x04; KeyEvent.KEYCODE_B -> 0x05
            KeyEvent.KEYCODE_C -> 0x06; KeyEvent.KEYCODE_D -> 0x07
            KeyEvent.KEYCODE_E -> 0x08; KeyEvent.KEYCODE_F -> 0x09
            KeyEvent.KEYCODE_G -> 0x0A; KeyEvent.KEYCODE_H -> 0x0B
            KeyEvent.KEYCODE_I -> 0x0C; KeyEvent.KEYCODE_J -> 0x0D
            KeyEvent.KEYCODE_K -> 0x0E; KeyEvent.KEYCODE_L -> 0x0F
            KeyEvent.KEYCODE_M -> 0x10; KeyEvent.KEYCODE_N -> 0x11
            KeyEvent.KEYCODE_O -> 0x12; KeyEvent.KEYCODE_P -> 0x13
            KeyEvent.KEYCODE_Q -> 0x14; KeyEvent.KEYCODE_R -> 0x15
            KeyEvent.KEYCODE_S -> 0x16; KeyEvent.KEYCODE_T -> 0x17
            KeyEvent.KEYCODE_U -> 0x18; KeyEvent.KEYCODE_V -> 0x19
            KeyEvent.KEYCODE_W -> 0x1A; KeyEvent.KEYCODE_X -> 0x1B
            KeyEvent.KEYCODE_Y -> 0x1C; KeyEvent.KEYCODE_Z -> 0x1D
            KeyEvent.KEYCODE_1 -> 0x1E; KeyEvent.KEYCODE_2 -> 0x1F
            KeyEvent.KEYCODE_3 -> 0x20; KeyEvent.KEYCODE_4 -> 0x21
            KeyEvent.KEYCODE_5 -> 0x22; KeyEvent.KEYCODE_6 -> 0x23
            KeyEvent.KEYCODE_7 -> 0x24; KeyEvent.KEYCODE_8 -> 0x25
            KeyEvent.KEYCODE_9 -> 0x26; KeyEvent.KEYCODE_0 -> 0x27
            KeyEvent.KEYCODE_ENTER -> 0x28; KeyEvent.KEYCODE_ESCAPE -> 0x29
            KeyEvent.KEYCODE_DEL -> 0x2A; KeyEvent.KEYCODE_TAB -> 0x2B
            KeyEvent.KEYCODE_SPACE -> 0x2C
            KeyEvent.KEYCODE_DPAD_UP -> 0x52; KeyEvent.KEYCODE_DPAD_DOWN -> 0x51
            KeyEvent.KEYCODE_DPAD_LEFT -> 0x50; KeyEvent.KEYCODE_DPAD_RIGHT -> 0x4F
            KeyEvent.KEYCODE_F1 -> 0x3A; KeyEvent.KEYCODE_F2 -> 0x3B
            KeyEvent.KEYCODE_F3 -> 0x3C; KeyEvent.KEYCODE_F4 -> 0x3D
            KeyEvent.KEYCODE_F5 -> 0x3E; KeyEvent.KEYCODE_F6 -> 0x3F
            KeyEvent.KEYCODE_F7 -> 0x40; KeyEvent.KEYCODE_F8 -> 0x41
            KeyEvent.KEYCODE_F9 -> 0x42; KeyEvent.KEYCODE_F10 -> 0x43
            KeyEvent.KEYCODE_F11 -> 0x44; KeyEvent.KEYCODE_F12 -> 0x45
            else -> 0x00
        }.toByte()
    }

    private fun requestPermissions() {
        val permissions = mutableListOf<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // Android 12+
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.BLUETOOTH_CONNECT)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADVERTISE)
                != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH)
                != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.BLUETOOTH)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADMIN)
                != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.BLUETOOTH_ADMIN)
            }
        }

        if (permissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permissions.toTypedArray(),
                REQUEST_BLUETOOTH_PERMISSIONS)
        } else {
            hidManager.register()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_BLUETOOTH_PERMISSIONS) {
            if (grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                hidManager.register()
            } else {
                statusText.text = "Bluetooth permissions required"
                Toast.makeText(this, "Please grant Bluetooth permissions", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        hidManager.unregister()
    }
}
