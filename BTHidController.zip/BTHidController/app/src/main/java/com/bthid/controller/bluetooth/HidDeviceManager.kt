package com.bthid.controller.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log

/**
 * Manages the Bluetooth HID Device profile.
 * This makes the phone appear as a physical Bluetooth mouse + keyboard to any paired device.
 * Uses the BluetoothHidDevice API (available since Android 9 / API 28).
 */
@SuppressLint("MissingPermission")
class HidDeviceManager(private val context: Context) {

    companion object {
        private const val TAG = "HidDeviceManager"

        // HID Report Descriptor: Combined Mouse + Keyboard
        // Mouse: buttons (3), X, Y, scroll wheel
        // Keyboard: modifier keys + 6 key rollover
        val HID_REPORT_DESCRIPTOR = byteArrayOf(
            // ---- MOUSE ----
            0x05.toByte(), 0x01.toByte(),  // Usage Page (Generic Desktop)
            0x09.toByte(), 0x02.toByte(),  // Usage (Mouse)
            0xA1.toByte(), 0x01.toByte(),  // Collection (Application)
            0x85.toByte(), 0x01.toByte(),  //   Report ID (1)
            0x09.toByte(), 0x01.toByte(),  //   Usage (Pointer)
            0xA1.toByte(), 0x00.toByte(),  //   Collection (Physical)
            // Buttons
            0x05.toByte(), 0x09.toByte(),  //     Usage Page (Buttons)
            0x19.toByte(), 0x01.toByte(),  //     Usage Minimum (1)
            0x29.toByte(), 0x03.toByte(),  //     Usage Maximum (3)
            0x15.toByte(), 0x00.toByte(),  //     Logical Minimum (0)
            0x25.toByte(), 0x01.toByte(),  //     Logical Maximum (1)
            0x95.toByte(), 0x03.toByte(),  //     Report Count (3)
            0x75.toByte(), 0x01.toByte(),  //     Report Size (1)
            0x81.toByte(), 0x02.toByte(),  //     Input (Data, Variable, Absolute)
            0x95.toByte(), 0x01.toByte(),  //     Report Count (1)
            0x75.toByte(), 0x05.toByte(),  //     Report Size (5) - padding
            0x81.toByte(), 0x03.toByte(),  //     Input (Constant)
            // X, Y movement
            0x05.toByte(), 0x01.toByte(),  //     Usage Page (Generic Desktop)
            0x09.toByte(), 0x30.toByte(),  //     Usage (X)
            0x09.toByte(), 0x31.toByte(),  //     Usage (Y)
            0x09.toByte(), 0x38.toByte(),  //     Usage (Wheel)
            0x15.toByte(), 0x81.toByte(),  //     Logical Minimum (-127)
            0x25.toByte(), 0x7F.toByte(),  //     Logical Maximum (127)
            0x75.toByte(), 0x08.toByte(),  //     Report Size (8)
            0x95.toByte(), 0x03.toByte(),  //     Report Count (3)
            0x81.toByte(), 0x06.toByte(),  //     Input (Data, Variable, Relative)
            0xC0.toByte(),                  //   End Collection
            0xC0.toByte(),                  // End Collection

            // ---- KEYBOARD ----
            0x05.toByte(), 0x01.toByte(),  // Usage Page (Generic Desktop)
            0x09.toByte(), 0x06.toByte(),  // Usage (Keyboard)
            0xA1.toByte(), 0x01.toByte(),  // Collection (Application)
            0x85.toByte(), 0x02.toByte(),  //   Report ID (2)
            // Modifier keys
            0x05.toByte(), 0x07.toByte(),  //   Usage Page (Key Codes)
            0x19.toByte(), 0xE0.toByte(),  //   Usage Minimum (224) - Left Ctrl
            0x29.toByte(), 0xE7.toByte(),  //   Usage Maximum (231) - Right GUI
            0x15.toByte(), 0x00.toByte(),  //   Logical Minimum (0)
            0x25.toByte(), 0x01.toByte(),  //   Logical Maximum (1)
            0x75.toByte(), 0x01.toByte(),  //   Report Size (1)
            0x95.toByte(), 0x08.toByte(),  //   Report Count (8)
            0x81.toByte(), 0x02.toByte(),  //   Input (Data, Variable, Absolute)
            // Reserved byte
            0x95.toByte(), 0x01.toByte(),  //   Report Count (1)
            0x75.toByte(), 0x08.toByte(),  //   Report Size (8)
            0x81.toByte(), 0x01.toByte(),  //   Input (Constant)
            // Key array (6 keys)
            0x95.toByte(), 0x06.toByte(),  //   Report Count (6)
            0x75.toByte(), 0x08.toByte(),  //   Report Size (8)
            0x15.toByte(), 0x00.toByte(),  //   Logical Minimum (0)
            0x25.toByte(), 0x65.toByte(),  //   Logical Maximum (101)
            0x05.toByte(), 0x07.toByte(),  //   Usage Page (Key Codes)
            0x19.toByte(), 0x00.toByte(),  //   Usage Minimum (0)
            0x29.toByte(), 0x65.toByte(),  //   Usage Maximum (101)
            0x81.toByte(), 0x00.toByte(),  //   Input (Data, Array)
            0xC0.toByte()                   // End Collection
        )

        // SDP record name shown to the paired device
        private const val SDP_NAME = "BT HID Controller"
        private const val SDP_DESCRIPTION = "Bluetooth Mouse & Keyboard"
        private const val SDP_PROVIDER = "BTHid"
    }

    private val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val bluetoothAdapter = bluetoothManager.adapter

    private var hidDevice: BluetoothHidDevice? = null
    private var connectedDevice: BluetoothDevice? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    var onStateChanged: ((String) -> Unit)? = null
    var onDeviceConnected: ((BluetoothDevice) -> Unit)? = null
    var onDeviceDisconnected: (() -> Unit)? = null

    private val hidCallback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            Log.d(TAG, "App status changed: registered=$registered")
            mainHandler.post {
                if (registered) {
                    onStateChanged?.invoke("Ready — waiting for connection")
                    // Make discoverable
                    setDiscoverable()
                } else {
                    onStateChanged?.invoke("HID profile unregistered")
                }
            }
        }

        override fun onConnectionStateChanged(device: BluetoothDevice, state: Int) {
            Log.d(TAG, "Connection state: $state for ${device.name}")
            mainHandler.post {
                when (state) {
                    BluetoothProfile.STATE_CONNECTED -> {
                        connectedDevice = device
                        onStateChanged?.invoke("Connected to ${device.name ?: device.address}")
                        onDeviceConnected?.invoke(device)
                    }
                    BluetoothProfile.STATE_DISCONNECTED -> {
                        connectedDevice = null
                        onStateChanged?.invoke("Disconnected — waiting for connection")
                        onDeviceDisconnected?.invoke()
                    }
                    BluetoothProfile.STATE_CONNECTING -> {
                        onStateChanged?.invoke("Connecting to ${device.name ?: device.address}...")
                    }
                }
            }
        }

        override fun onGetReport(device: BluetoothDevice, type: Byte, id: Byte, bufferSize: Int) {
            hidDevice?.replyReport(device, type, id, ByteArray(bufferSize))
        }

        override fun onSetReport(device: BluetoothDevice, type: Byte, id: Byte, data: ByteArray) {
            hidDevice?.reportError(device, BluetoothHidDevice.ERROR_RSP_SUCCESS)
        }
    }

    fun register() {
        if (bluetoothAdapter == null) {
            onStateChanged?.invoke("Bluetooth not available")
            return
        }
        if (!bluetoothAdapter.isEnabled) {
            onStateChanged?.invoke("Please enable Bluetooth")
            return
        }

        val sdp = BluetoothHidDeviceAppSdpSettings(
            SDP_NAME, SDP_DESCRIPTION, SDP_PROVIDER,
            BluetoothHidDevice.SUBCLASS1_COMBO, HID_REPORT_DESCRIPTOR
        )

        bluetoothAdapter.getProfileProxy(context, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                hidDevice = proxy as BluetoothHidDevice
                hidDevice?.registerApp(sdp, null, null,
                    { it.run() }, hidCallback)
                Log.d(TAG, "HID profile service connected")
            }

            override fun onServiceDisconnected(profile: Int) {
                hidDevice = null
                mainHandler.post { onStateChanged?.invoke("HID service disconnected") }
            }
        }, BluetoothProfile.HID_DEVICE)
    }

    fun unregister() {
        hidDevice?.unregisterApp()
        hidDevice = null
    }

    @SuppressLint("MissingPermission")
    private fun setDiscoverable() {
        // Note: In Android 12+, discoverability is managed via system dialog
        // The app should prompt the user to make the device discoverable
        bluetoothAdapter?.name = "BTHid Controller"
    }

    // ---- MOUSE REPORTS ----

    /**
     * Send a mouse movement report.
     * dx/dy are relative movement (-127 to 127)
     * buttons: bit0=left, bit1=right, bit2=middle
     */
    fun sendMouseMove(dx: Int, dy: Int, buttons: Int = 0, scroll: Int = 0) {
        val device = connectedDevice ?: return
        val report = byteArrayOf(
            buttons.toByte(),
            dx.coerceIn(-127, 127).toByte(),
            dy.coerceIn(-127, 127).toByte(),
            scroll.coerceIn(-127, 127).toByte()
        )
        hidDevice?.sendReport(device, 1, report)
    }

    fun sendMouseButton(button: Int, pressed: Boolean) {
        val device = connectedDevice ?: return
        val buttons = if (pressed) button else 0
        val report = byteArrayOf(buttons.toByte(), 0, 0, 0)
        hidDevice?.sendReport(device, 1, report)
    }

    fun sendMouseClick(button: Int = 1) {
        sendMouseButton(button, true)
        mainHandler.postDelayed({ sendMouseButton(button, false) }, 50)
    }

    fun sendScroll(amount: Int) {
        val device = connectedDevice ?: return
        val report = byteArrayOf(0, 0, 0, amount.coerceIn(-127, 127).toByte())
        hidDevice?.sendReport(device, 1, report)
        mainHandler.postDelayed({
            hidDevice?.sendReport(device, 1, byteArrayOf(0, 0, 0, 0))
        }, 50)
    }

    // ---- KEYBOARD REPORTS ----

    /**
     * Send a keyboard report.
     * modifier: bitmask (Ctrl=1, Shift=2, Alt=4, GUI=8, etc.)
     * keyCodes: up to 6 HID key codes simultaneously
     */
    fun sendKeyReport(modifier: Int, keyCodes: ByteArray) {
        val device = connectedDevice ?: return
        val report = ByteArray(8)
        report[0] = modifier.toByte()
        report[1] = 0 // reserved
        keyCodes.take(6).forEachIndexed { i, k -> report[2 + i] = k }
        hidDevice?.sendReport(device, 2, report)
    }

    fun sendKeyPress(modifier: Int, keyCode: Byte) {
        sendKeyReport(modifier, byteArrayOf(keyCode))
        mainHandler.postDelayed({ sendKeyReport(0, byteArrayOf(0)) }, 50)
    }

    fun sendKeyRelease() {
        sendKeyReport(0, byteArrayOf(0))
    }

    fun sendText(text: String) {
        for (char in text) {
            val (modifier, keyCode) = charToHid(char)
            sendKeyPress(modifier, keyCode)
            Thread.sleep(30)
        }
    }

    val isConnected get() = connectedDevice != null

    /**
     * Maps common characters to HID key codes.
     * Returns Pair(modifier, keyCode)
     */
    private fun charToHid(char: Char): Pair<Int, Byte> {
        val shift = 0x02 // Left Shift modifier
        return when (char) {
            'a' -> Pair(0, 0x04); 'b' -> Pair(0, 0x05); 'c' -> Pair(0, 0x06)
            'd' -> Pair(0, 0x07); 'e' -> Pair(0, 0x08); 'f' -> Pair(0, 0x09)
            'g' -> Pair(0, 0x0A); 'h' -> Pair(0, 0x0B); 'i' -> Pair(0, 0x0C)
            'j' -> Pair(0, 0x0D); 'k' -> Pair(0, 0x0E); 'l' -> Pair(0, 0x0F)
            'm' -> Pair(0, 0x10); 'n' -> Pair(0, 0x11); 'o' -> Pair(0, 0x12)
            'p' -> Pair(0, 0x13); 'q' -> Pair(0, 0x14); 'r' -> Pair(0, 0x15)
            's' -> Pair(0, 0x16); 't' -> Pair(0, 0x17); 'u' -> Pair(0, 0x18)
            'v' -> Pair(0, 0x19); 'w' -> Pair(0, 0x1A); 'x' -> Pair(0, 0x1B)
            'y' -> Pair(0, 0x1C); 'z' -> Pair(0, 0x1D)
            'A' -> Pair(shift, 0x04); 'B' -> Pair(shift, 0x05); 'C' -> Pair(shift, 0x06)
            'D' -> Pair(shift, 0x07); 'E' -> Pair(shift, 0x08); 'F' -> Pair(shift, 0x09)
            'G' -> Pair(shift, 0x0A); 'H' -> Pair(shift, 0x0B); 'I' -> Pair(shift, 0x0C)
            'J' -> Pair(shift, 0x0D); 'K' -> Pair(shift, 0x0E); 'L' -> Pair(shift, 0x0F)
            'M' -> Pair(shift, 0x10); 'N' -> Pair(shift, 0x11); 'O' -> Pair(shift, 0x12)
            'P' -> Pair(shift, 0x13); 'Q' -> Pair(shift, 0x14); 'R' -> Pair(shift, 0x15)
            'S' -> Pair(shift, 0x16); 'T' -> Pair(shift, 0x17); 'U' -> Pair(shift, 0x18)
            'V' -> Pair(shift, 0x19); 'W' -> Pair(shift, 0x1A); 'X' -> Pair(shift, 0x1B)
            'Y' -> Pair(shift, 0x1C); 'Z' -> Pair(shift, 0x1D)
            '1' -> Pair(0, 0x1E); '2' -> Pair(0, 0x1F); '3' -> Pair(0, 0x20)
            '4' -> Pair(0, 0x21); '5' -> Pair(0, 0x22); '6' -> Pair(0, 0x23)
            '7' -> Pair(0, 0x24); '8' -> Pair(0, 0x25); '9' -> Pair(0, 0x26)
            '0' -> Pair(0, 0x27)
            '\n' -> Pair(0, 0x28) // Enter
            '\t' -> Pair(0, 0x2B) // Tab
            ' ' -> Pair(0, 0x2C) // Space
            '-' -> Pair(0, 0x2D); '_' -> Pair(shift, 0x2D)
            '=' -> Pair(0, 0x2E); '+' -> Pair(shift, 0x2E)
            '[' -> Pair(0, 0x2F); '{' -> Pair(shift, 0x2F)
            ']' -> Pair(0, 0x30); '}' -> Pair(shift, 0x30)
            '\\' -> Pair(0, 0x31); '|' -> Pair(shift, 0x31)
            ';' -> Pair(0, 0x33); ':' -> Pair(shift, 0x33)
            '\'' -> Pair(0, 0x34); '"' -> Pair(shift, 0x34)
            '`' -> Pair(0, 0x35); '~' -> Pair(shift, 0x35)
            ',' -> Pair(0, 0x36); '<' -> Pair(shift, 0x36)
            '.' -> Pair(0, 0x37); '>' -> Pair(shift, 0x37)
            '/' -> Pair(0, 0x38); '?' -> Pair(shift, 0x38)
            '!' -> Pair(shift, 0x1E); '@' -> Pair(shift, 0x1F)
            '#' -> Pair(shift, 0x20); '$' -> Pair(shift, 0x21)
            '%' -> Pair(shift, 0x22); '^' -> Pair(shift, 0x23)
            '&' -> Pair(shift, 0x24); '*' -> Pair(shift, 0x25)
            '(' -> Pair(shift, 0x26); ')' -> Pair(shift, 0x27)
            else -> Pair(0, 0x00)
        }.let { Pair(it.first, it.second.toByte()) }
    }
}
