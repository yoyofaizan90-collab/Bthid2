# BT HID Controller

Turn your Android phone into a Bluetooth mouse + keyboard for any other device — including your spare phone that accepts physical USB input via OTG.

## How it works

Your primary phone registers itself as a **Bluetooth HID peripheral** (the same profile used by physical Bluetooth mice and keyboards). The spare phone pairs with it exactly as it would pair with a real Bluetooth mouse/keyboard — no app needed on the spare phone.

## Requirements

- **Primary phone** (the controller): Android 9+ (API 28+), Bluetooth HID Device profile support
- **Spare phone** (the controlled): Any Android that accepts Bluetooth HID input — if it works with a physical BT mouse, it'll work with this app

## Build & Install

1. Open the project in **Android Studio**
2. Connect your primary phone via USB with developer mode + USB debugging enabled
3. Click **Run** — the app installs directly

Or build an APK:
```
./gradlew assembleDebug
```
APK will be at `app/build/outputs/apk/debug/app-debug.apk`

## First-time pairing (do this once)

1. Open the app on your primary phone
2. Tap **"Pair"** — this makes your phone discoverable for 2 minutes
3. On the spare phone (using your physical OTG mouse), go to:
   **Settings → Bluetooth → Pair new device**
4. You should see **"BTHid Controller"** in the list — tap it to pair
5. The status dot turns **green** and shows "Connected to [device name]"
6. Done! You can now control the spare phone from your primary phone

## Using the app

### Trackpad
- **Single finger drag** → moves the cursor
- **Tap** → left click
- **Speed slider** → adjusts cursor sensitivity

### Mouse buttons
- Left Click, Right Click, Middle Click buttons
- Scroll Up / Scroll Down (hold for fast scroll)

### Keyboard (tap ⌨ Keyboard to expand)
- **Ctrl / Shift / Alt toggles** → sticky modifiers, stay active until tapped again
- **Esc, Tab, Backspace, Enter** → special key buttons  
- **Arrow keys** → navigation
- **Type & Send** → type text in the field and tap Send to type it character by character on the spare phone

## Troubleshooting

**"BTHid Controller" not showing in spare phone's Bluetooth scan:**
- Make sure you tapped Pair in the app first (makes it discoverable for 2 min)
- Try toggling Bluetooth off/on on the spare phone

**App stuck on "Initializing":**
- Grant Bluetooth permissions when prompted
- On Android 12+, also grant "Nearby devices" permission in Settings

**Cursor moves but clicks don't register:**
- Rare issue with some devices — try unpairing and re-pairing

**My phone doesn't support HID Device profile:**
- Most phones from 2019+ support it. Older or heavily modified ROMs may not.
- You'll know immediately — the app will fail to register and show an error.

## Architecture

```
HidDeviceManager.kt     — Bluetooth HID profile, report descriptor, mouse/keyboard reports
MainActivity.kt         — UI, trackpad gesture handling, keyboard input
KeyCodes.kt             — HID key code constants
activity_main.xml       — Dark UI layout
```

The HID Report Descriptor defines both a mouse (Report ID 1) and keyboard (Report ID 2) in one device, so the spare phone sees a single combo peripheral.
